/*
  File for 'threads-term' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "devices/timer.h"

void test_threads_term(void) 
{
  msg("Not implemented.");
}
