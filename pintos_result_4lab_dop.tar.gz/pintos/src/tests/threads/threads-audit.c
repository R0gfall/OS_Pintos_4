/*
  File for 'threads-audit' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "devices/timer.h"

void test_threads_audit(void) 
{
  msg("Not implemented.");
}
