/*
#include <stdio.h>
#include <syscall.h>

int 
main(int argc UNUSED, const char* argv[] UNUSED)
{
  printf("Not implemented.\n");  
  return EXIT_SUCCESS;
}*/

#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>
#include "lib/kernel/console.h"
#include <string.h>



int
funcPower(int base, int exponent) {
    int result = 1;
    for (int i = 0; i < exponent; i++) {
        result *= base;
    }
    return result;
}

int
convertToDecimal(char number[], int base) {
    int decimal = 0;
    int power = 0;

    // Начинаем с конца числа
    for (int i = strlen(number) - 1; i >= 0; i--) {
        // Получаем числовое значение символа
        int digit;
        if (number[i] >= '0' && number[i] <= '9') {
            digit = number[i] - '0';
        } else if (number[i] >= 'A' && number[i] <= 'F') {
            digit = number[i] - 'A' + 10;
        } else if (number[i] >= 'a' && number[i] <= 'f') {
            digit = number[i] - 'a' + 10;
        } else {
            printf("Ошибка: Некорректный символ в числе\n");
            return -1;
        }

        // Добавляем в десятичное число с учетом текущего разряда
        decimal += digit * funcPower(base, power);
        power++;
    }

    return decimal;
}



void
convertToNewSystem(char *number, int oldSystem, int newSystem) {


  // Преобразуем строковое число в десятичное
  // Maximum int number: 2147483647
  int decimalNumber = convertToDecimal(number, oldSystem);
  

  //char* sysNumber = malloc(33 * sizeof(char));  // Выделяем память для строки
  char sysNumber[33];
  // Maximum lenth number: 32
  switch(newSystem){
  case 2:
    // >>>
    //char binNumber[33];
    for (int i = 31; i >= 0; i--) {
      sysNumber[31 - i] = ((decimalNumber >> i) & 1) ? '1' : '0';
    }
    sysNumber[32] = '\0'; 
    printf("%s\n", sysNumber);
    return;

  case 8:
    // >>>
    //char octNumber[33];
    snprintf(sysNumber, sizeof(sysNumber), "%o", decimalNumber);
    printf("%s\n", sysNumber);
    return;
    

  case 10:
    // >>>
    //char decNumber[33];
    snprintf(sysNumber, sizeof(sysNumber), "%d", decimalNumber);
    printf("%s\n", sysNumber);
    return;

  case 16:
    // >>>
    //char hexNumber[33];
    snprintf(sysNumber, sizeof(sysNumber), "%X", decimalNumber);
    //return sysNumber[33];
    printf("%s\n", sysNumber);
    return;

  default:
    // >>>
    printf("Incorrect final numeral system >>> third argument!\n");
    exit(EXIT_FAILURE);
  }
  
}


int 
main(int argc UNUSED, const char* argv[] UNUSED)
{
  if (argc != 4) {
    printf("Использование: %s <число> <исходная система> <целевая система>\n", argv[0]);
    exit(EXIT_FAILURE);
  } 
 
  //char test[40];
  char* originalNumber = argv[1]; // number 
  int oldSystem = atoi(argv[2]);  // start numeral system
  int newSystem = atoi(argv[3]);  // final numeral system


  //                TEST
  //
  //------------------------------------------------------------------------------------
  /*int finalNumber;
  finalNumber = convertToDecimal(originalNumber, oldSystem);
  printf("%d\n", finalNumber);*/

  //cheak correct work snprintf

  //snprintf(test, sizeof(test), "%X", oldSystem);

  //>>>

  //printf("%s\n%d\n%d\n", originalNumber, oldSystem, newSystem);
  //printf("%s\n", test);

  //cheak value oldSystem 

  //-------------------------------------------------------------------------------------



  if ((oldSystem != 2) && (oldSystem != 8) && (oldSystem != 10) && (oldSystem != 16)){
    printf("Incorrect start numeral system >>> second argument!\n");
    exit(EXIT_FAILURE);
  }

  //char* finalNumber = convertToNewSystem(originalNumber, oldSystem, newSystem);
  convertToNewSystem(originalNumber, oldSystem, newSystem);
  //printf("%s\n", finalNumber);
  //free(finalNumber);
  return EXIT_SUCCESS;

}